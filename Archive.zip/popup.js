// Перезагрузка виджета
const reload = document.querySelector('[value="reboot"]')
	reload.addEventListener('click', () => window.location.reload())

// Скрыть/показать кнопку видео интервью
const list = document.getElementById('position');
const button = document.querySelector('[value="conference"]');
	list.addEventListener('change', function() {
		if (this.value === 'interview') {
			button.style.display = 'block'
		} else {
			button.style.display = 'none'
		}
	})

// Активация редактирования поля с ФИО и т.д.
const pencil = document.getElementById('pencil')
const contacts = document.querySelectorAll('.submit-form__contact')
	for (const contact of contacts) {
		pencil.addEventListener('click', () => contact.removeAttribute('disabled', 'true'), contact.classList.toggle('enable'))
	}

// Уведомление об отправке теста
const notice = document.getElementById('notice')
const btns = document.querySelectorAll('.btn')
for (const btn of btns) {
	btn.addEventListener('click', function () {
		notice.style.display = 'block'
		setTimeout(function() {
			notice.style.display = 'none'
		}, 2000)
	})
}	

// Изменение цвета кнопки для того, чтобы за одну сессию было понятно, что отправила HR, а что еще нет
const activeButtons = document.querySelectorAll(".btn")
for (const btn of activeButtons) {
	btn.addEventListener('click', function () {
		btn.classList.toggle('active')
	})
}






